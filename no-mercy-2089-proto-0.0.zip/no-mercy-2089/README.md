# NO MERCY 2089
*Miami no perdona.*

## Probar la versión web (en tu ordenador)
Requisito: instalar Node.js 22 (https://nodejs.org).
```
npm install
npm run dev
```
Abre la dirección que muestre (normalmente http://localhost:5173).

## Ejecutar los tests
```
npm test
```

## Obtener el .exe
1. Sube este proyecto a un repositorio de GitHub (rama `main`).
2. Pestaña **Actions** → "Build .exe (Windows)" (se ejecuta solo al subir; o botón *Run workflow*).
3. Cuando termine, entra en la ejecución y descarga el artefacto **NO-MERCY-2089-exe** (zip con el .exe portable).
4. Descomprime y haz doble clic.

## Estado
- Prototipo 0.0 (Infraestructura): escrito, **pendiente de verificar** (tests/build/.exe no se pudieron ejecutar en el entorno sin internet donde se escribió).
- Siguiente: 0.1 Movimiento, solo tras feedback y aprobación del 0.0.
